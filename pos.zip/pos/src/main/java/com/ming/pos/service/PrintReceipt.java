package com.ming.pos.service;

import com.ming.pos.model.Product;
import com.ming.pos.model.ShoppingCart;

import java.text.DecimalFormat;

public class PrintReceipt implements GenerateReceipt {

    private final DecimalFormat formater = new DecimalFormat("0.00");

    @Override
    public void generate(ShoppingCart shoppingCart) {

        for(Product product : shoppingCart.getShoppingCart()){
            System.out.println(product);
        }
        System.out.println("Sales Taxes: " + formater.format(shoppingCart.getTotalSalesTaxesAmount()));
        System.out.println("Total: " + formater.format(shoppingCart.getTotalAmount()));
        System.out.println();
    }
}
