package com.ming.pos.model;


import java.util.ArrayList;

public class ShoppingCart {

    private ArrayList <Product> shoppingCart;
    private double totalSalesTaxesAmount;
    private double totalAmount;


    public ShoppingCart() {
        shoppingCart = new ArrayList<>();
    }

    public double getTotalSalesTaxesAmount() {
        return totalSalesTaxesAmount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public ArrayList<Product> getShoppingCart() {
        return shoppingCart;
    }

    public void addProduct(Product product){
        shoppingCart.add(product);
        totalSalesTaxesAmount += product.getSalesTaxAmount();
        totalAmount += product.getTotalAmount();
    }
}
