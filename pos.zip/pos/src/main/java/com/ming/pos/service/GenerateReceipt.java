package com.ming.pos.service;

import com.ming.pos.model.ShoppingCart;

public interface GenerateReceipt {

    void generate(ShoppingCart shoppingCart);
}
