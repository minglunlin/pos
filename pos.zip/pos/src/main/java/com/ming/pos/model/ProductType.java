package com.ming.pos.model;

public enum ProductType {
    REGULAR(""), EXEMPT("chocolate|pills|wine|book"), IMPORTED("imported");

    private ProductType(final String pattern){
        this.pattern = pattern;
    }

    private String pattern;

    public String getPattern() {
        return pattern;
    }
}
