package com.ming.pos.service;

public interface RoundingPolicy {

    default double applyRoundingPolicy(double amount){
        return Math.ceil((amount * 20.0)) / 20.0;
    }
}
