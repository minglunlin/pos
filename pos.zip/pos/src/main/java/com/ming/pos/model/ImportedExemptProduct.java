package com.ming.pos.model;

import com.ming.pos.service.RoundingPolicy;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class ImportedExemptProduct extends Product implements RoundingPolicy {


    private Double importedExemptSaleTaxRate = .05;

    public ImportedExemptProduct() {
        super();
    }

    public ImportedExemptProduct(String name, Double unitPrice, int quantity) {
        super(name, unitPrice, quantity);
        calculateSalesTax();
    }

    @Override
    public void calculateSalesTax(){
        saleTaxAmount =  applyRoundingPolicy((unitPrice * importedExemptSaleTaxRate) * quantity);
        taxIncludedPrice = saleTaxAmount + (quantity * unitPrice);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ImportedExemptProduct that = (ImportedExemptProduct) o;
        return importedExemptSaleTaxRate == that.importedExemptSaleTaxRate;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), importedExemptSaleTaxRate);
    }

}
