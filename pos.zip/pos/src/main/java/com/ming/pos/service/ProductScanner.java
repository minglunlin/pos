package com.ming.pos.service;

import com.ming.pos.model.ShoppingCart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class ProductScanner  {

    final Logger LOGGER = LoggerFactory.getLogger(getClass());
    private PatternMatcher patternMatcher = new ProductMatcher();
    private ShoppingCart shoppingCart;


    public ShoppingCart scanProduct(String cartItems) {

        StopWatch watch = new StopWatch();
        watch.start();

        shoppingCart = new ShoppingCart();

        Path path = Paths.get(cartItems);

        boolean exists = Files.exists(path);

        if (! exists){
            System.out.println(cartItems + " is not in the file system. Please contact the administrator.");
            LOGGER.error("FileNotFoundException: " + cartItems);
        } else {

            try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.ISO_8859_1)) {

                String lineItem = reader.readLine();

                while (lineItem != null) {
                    shoppingCart.addProduct(patternMatcher.matchProduct(lineItem));
                    lineItem = reader.readLine();
                }

            } catch (IOException ioex) {
                LOGGER.error("IOException", ioex);
                ioex.printStackTrace();
            }
        }

        watch.stop();
        //System.out.println("Time Elapsed to process this file : " + watch.getTotalTimeMillis());

        return shoppingCart;
    }




}
