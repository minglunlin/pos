package com.ming.pos.service;

import com.ming.pos.model.Product;
import com.ming.pos.model.ShoppingCart;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductMatcherTest {

    private String exemptProduct = "1 book at 12.49";
    private String importedProduct = "1 imported bottle of perfume at 47.50";
    private String basicProduct = "1 bottle of perfume at 18.99";
    private String importedExemptProduct = "1 box of imported chocolates at 11.25";
    private String expectedExemptProduct = "1 book: 12.49";
    private String expectedImportedProduct = "1 imported bottle of perfume: 54.65";
    private String expectedBasicProduct = "1 bottle of perfume: 20.89";
    private String expectedimportedExemptProduct = "1 box of imported chocolates: 11.85";

    private PatternMatcher patternMatcher = new ProductMatcher();
    private ShoppingCart  shoppingCart = new ShoppingCart();
    private PrintReceipt printReceipt = new PrintReceipt();

    @Test
    void matchExemptProduct() {
        Product product = patternMatcher.matchProduct(exemptProduct);
        assertEquals(expectedExemptProduct, product.toString());
    }

    @Test
    void matchImportedProduct() {
        Product product = patternMatcher.matchProduct(importedProduct);
        assertEquals(expectedImportedProduct, product.toString());
    }

    @Test
    void matchBasicProduct() {
        Product product = patternMatcher.matchProduct(basicProduct);
        assertEquals(expectedBasicProduct, product.toString());
    }

    @Test
    void matchImportedExemptProduct() {
        Product product = patternMatcher.matchProduct(importedExemptProduct);
        assertEquals(expectedimportedExemptProduct, product.toString());
    }


}