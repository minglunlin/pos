package com.ming.pos.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintReceiptTest {

    @Test
    void generate() {
    }
}